// New Project Started from Scratch
// Date Started: Dec 6, 1996
// Written By Franco Gaetan
// This Source in NOT Free
//

#include "draw.h"
#include <dos.h>
#include <bios.h>
#include <stdio.h>
#include <stdlib.h>
#include <alloc.h>
#include <memory.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <conio.h>

// Defines

#define TOTALSHAPE 10
#define TOTALANIMS 10
#define TOTALOBJECTS 20


// Prototypes

void main(void);
int getch(void);
int fileread(void);
int fileread2(void);
void ClearData(void);
void initarray(void);
void copypagedn();
void copypageup();
void copypageLtoR(void);
void copypageRtoL(void);
void Current_Screen(void);


//Globals

int layarr[100][100];		// Row & Coloumn
int curval=0;					// Current Value
char far *p;
char far *st1;
char far *screen = MK_FP(0xa000,0);

int rw=0,sp=0;
unsigned int offset=0;




//////////////////////////////
// Virtual Screen
/////////////////////////////
// Start 32*320+32 Top Left
// Bottom right is 32*320-32 = 10208
//
// VirStart = 40960 + 10272	= 51232
// VirEnd   = 64000 - 10208     = 53792
// A000 = 40960
// FA00 = 64000
//
int VirSoff=10272;
char *sw;			// Screen Width
char *ba;			// Bytes Accross

char ScnStart=0xa000+10272;


char label[20]; 	// Filenames
char infst[20];
char stan[20];
char smap[20];

// External Variables
extern char far *dest;
extern int VirStart;


// Structures

struct savebg

	{
	int bgflag;
	char far backgnd[256];

	} savedarea[TOTALOBJECTS];


struct fshape
	{

		int w,h;
		int n,c;
		int flag;
		int rowflag;
		char far shp[260];
					// TOTALSHAPE  =  20
	} fshp[TOTALSHAPE];

struct animshape {
		int active;
		int animwidth;
		int animheight;
		int animox;
		int animoy;
		int animx;
		int animy;
		int prox;
		int animspeed;
		int currentshape;
		int oldshape;
		int max;
		int row;

		struct fshape *fshp[TOTALSHAPE];        // 10 Pointers to data

	 } animobjects[TOTALANIMS];




// Files
FILE *in, *mapin,*indata;


// **************************************************************************

void main(void)
{

	Init_Mode();
	initarray();
	Alloc_Vert_Screen();
	fileread();							// Read Background In 256 * 100 Shape
	fileread2();					// Read Structured Shapes Plus Attribs.
	Current_Screen();
//   extern void copycentre(char *source, char *dest, int ll, int nl,int av);
  //	ll = line length
  //	nl = number of lines
  //	av	= add value

	copycentre((dest+0x2820), (screen+0x2820),64,154,64);
//   void copycentre(char *source, char *dest, int ll, int nl, int av)
	getch();

	Free_Vert_Screen();
	Close_Mode();

}


int fileread(void)
{

	int s=0,i;
	struct fshape *p;

	if ((in = fopen("def1.std", "rb"))
		 == NULL)
	{
		fprintf(stderr, "Cannot open input file.\n");
		return 1;

	}

	i=0;
	for (s=0,p=&fshp[s];s<TOTALSHAPE && feof ;s++,p=&fshp[s],i=0)

	while (i<256)
	{
	*(p->shp+i)=fgetc(in);
	i++;
	}

	fclose(in);

	return 1;

}


int fileread2(void)
{

	int i,j,k,numobj,numrow;
	char far *p;

  //	ClearData();		// Clear the Array

	gotoxy (1,22);
	printf("Please enter Filename: ");
	fflush(stdin);  /* flush the input stream in case of bad input */

	scanf("%8s",label);

	strcpy(infst, label);
	strcpy(smap, label);

	strcat(label,".dat");

	strcat(infst,".inf");
	strcat(smap, ".map");

	if ((mapin = fopen(smap, "rb"))
	 == NULL)
	 {
	 fprintf(stderr, "Cannot open Standard file.\n");
	  return 1;
	 }

	if ((in = fopen(infst, "rb"))
		== NULL)
	{
	  fprintf(stderr, "Cannot open input file.\n");
	  return 1;
	}

	if ((indata = fopen(label, "rb")) == NULL)
	{
		  fprintf(stderr, "Cannot open output file.\n");
		  return 1;
	}

		for(i=0;i<100;i++)
		{
		  for(j=0;j<100;j++)
		  {
		  fscanf(mapin,"%d",&layarr[j][i]);
		  }

		}
	fread(animobjects,sizeof(animobjects),1,indata);


	p = st1;

	for (i=0;i<=9;i++)
	{
		for (j=0;j<=9;j++)
		{
		 animobjects[i].fshp[j]=(struct fshape *)p;
		 p+=sizeof(struct fshape);
		}

	}


	for (numrow=0;numrow<=9;numrow++)
	{

		for (numobj=0;numobj<TOTALSHAPE;numobj++)
		{
		 fread(animobjects[numrow].fshp[numobj],272l,1,in);
		}

	}

	fclose(mapin);
	fclose(in);
	fclose(indata);


	return 1;



}


void ClearData(void)
{
	int t,s,x,y;

	for (t=0;t<=9;t++)
	{
		for (s=0;s<=9;s++)
		{
			for (x=0;x<16;x++)
			{
				for (y=0;y<16;y++)
				{
				animobjects[t].fshp[s]->shp[x*16+y]=0;
				}
			}
		}

	}




}



void initarray(void)
{

	int i,j,s;
	char far *q;

	if ((p=(char far *)farmalloc(sizeof (struct fshape)*TOTALSHAPE*TOTALANIMS))==NULL)
	{
		printf("Could Not Allocate Memory for Objects\n");
		exit(1);
	}

	_fmemset(p,0,sizeof(struct fshape)*TOTALSHAPE*TOTALANIMS);

	st1 = p;


	for (i=0;i<TOTALANIMS;i++)
	{
		for (j=0;j<TOTALSHAPE;j++)
			{
			animobjects[i].fshp[j]=(struct fshape *)p;
			p+=sizeof(struct fshape);
			animobjects[i].animx=100;
			animobjects[i].animy=100;

			}
	}
	for (i=0;i<=9;i++)
	{
		savedarea[i].bgflag=0;
	}
	// int layarr[100][50];	// Row & Coloumn
	for (i=0;i<100;i++)
	{
		for (j=0;j<50;j++)
			{
			layarr[i][j]=-1;	// Row & Coloumn
			}
	}






}





void copypagedn()
{

//      printf("Start ASM");
	asm {
		 push ds
		 push es
		 push si
		 push di
		 mov ax,0xa000
		 mov es,ax
		 mov ds,ax

		 mov si, 0xf8c0
		 mov di, 0xfa00

		 mov cx, 16000
		 std
		 db 0x66
		 rep
		 movsw

		 pop di
		 pop si
		 pop es
		 pop ds
		 }
}



void copypageup()
{

//      printf("Start ASM");
	asm {
		 push ds
		 push es
		 push si
		 push di
		 mov ax,0xa000
		 mov es,ax
		 mov ds,ax

		 mov si, 0x140
		 mov di, 0

		 mov cx, 16000
		 cld
		 db 0x66
		 rep
		 movsw

		 pop di
		 pop si
		 pop es
		 pop ds
		 }
}



void copypageLtoR(void)
{

//      printf("Start ASM");
	asm {
		 push ds
		 push es
		 push si
		 push di
		 mov ax,0xa000
		 mov es,ax
		 mov ds,ax

		 mov si, 0xf9ff
		 mov di, 0xfa00

		 mov cx, 16000
		 std
		 db 0x66
		 rep
		 movsw

		 pop di
		 pop si
		 pop es
		 pop ds
		 }
}


void copypageRtoL(void)
{
	asm {
		 push ds
		 push es
		 push si
		 push di
		 mov ax,0xa000
		 mov es,ax
		 mov ds,ax

		 mov si, 1
		 mov di, 0

		 mov cx, 16000
		 cld
		 db 0x66
		 rep
		 movsw

		 pop di
		 pop si
		 pop es
		 pop ds
		 }
}



void PutImage(int offset)
{
	int o;
	offset=10;
	for (o=0;o<100;o++)
	{

	*(screen+offset+o)=1;
       }
}

void draw_screen(int rw, int sp)
{
	int ap=0;
	int dn=0;
	int cnt=0;
	int t,s,y,x;
	long int clr;

	for (t=0;t<=9;t++)
	{
		for (s=0;s<=9;s++)
		{
			if (animobjects[t].fshp[s]->flag==1)
			{
				for (x=0;x<16;x++)
				{
					for (y=0;y<16;y++)
					{
					*(screen+y+offset+ap+dn)=animobjects[t].fshp[s]->shp[x*16+y];
					}
					offset = offset + 320;      //bytes to next line
				}

				offset = 0;
				ap = ap +18;
			}
		}
		cnt = cnt + 18;
		dn = cnt * 320;
		offset=0;
		ap=0;


	}

}




void Current_Screen(void)
{
	int ap=0;
	int dn=0;
	int cnt=0;
	int t,s,y;
	long int clr;
	int x;
	float t1=0;

	rw = 0;
	sp =0;

	for (t=0;t<=10;t++)
	{
		for (s=0;s<=19;s++)
		{

			 curval = layarr[s][t];

			 if (curval >=0)
			 {
			 t1 = ((float)curval /10);
			 rw = t1;
			 t1 = t1 - rw;
			 t1 = t1 * 10;
			 sp = (int) (t1+.1);
			 }


			 for (x=0;x<16;x++)
			{
				for (y=0;y<16;y++)
				{
				if (curval>=0)
				{
				*(dest+y+offset+ap+dn)=animobjects[rw].fshp[sp]->shp[x*16+y];
				}
				else
				{
				*(dest+y+offset+ap+dn)=0;
				}

				}
				offset = offset + 320;      //bytes to next line
				}

				offset = 0;
				ap = ap +16;
			}
		cnt = cnt + 16;
		dn = cnt * 320;
		offset=0;
		ap=0;


		}


	}


